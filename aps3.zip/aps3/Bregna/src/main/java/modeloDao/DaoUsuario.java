
package modeloDao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.BeansUsuario;
import modeloConection.ConexaoBD;

/**
 *
 * @author Maicon Aparecido 08/03/2020
 */
public class DaoUsuario {
    ConexaoBD conex = new ConexaoBD();
    BeansUsuario mod = new BeansUsuario();
    
    public void Salvar(BeansUsuario mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into usuarios(usu_nome,usu_senha,usu_tipo) values(?,?,?) ");
            pst.setString(1, mod.getUsuNome());
            pst.setString(2, mod.getUsuSenha());
            pst.setString(3, mod.getUsuTipo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "User inserido com sucesso!");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Usuario não inserido: Falha!");
        }
        conex.desconecta();
    }
    
     public void Alterar(BeansUsuario mod){
            conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("update usuarios set usu_nome=?,usu_senha=?,usu_tipo=? where usu_cod=?"); // set table usuarios para edição/inserção de valores
            pst.setString(1, mod.getUsuNome());
            pst.setString(2, mod.getUsuSenha());
            pst.setString(3, mod.getUsuTipo());
            pst.setInt(4, mod.getUsuCod());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Exito ao alterar Usuário");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao alterar usuário\n"+ex);
        }
            conex.desconecta();
            
    }
     public BeansUsuario buscaUsuario(BeansUsuario mod) {
        conex.conexao();
        conex.executaConsulta("select * from usuarios where usu_nome like'%"+mod.getUsuPesquisa()+"%'");
        try {
            conex.rs.first();
            mod.setUsuCod(conex.rs.getInt("usu_cod"));
            mod.setUsuNome(conex.rs.getString("usu_nome"));
            mod.setUsuSenha(conex.rs.getString("usu_senha"));
            mod.setUsuTipo(conex.rs.getString("usu_tipo"));
        } catch (SQLException ex) {
          //  Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
          JOptionPane.showMessageDialog(null, "Usuario não encontrado");
        }
        conex.desconecta();
        return mod;
        
    } 
     public void Excluir(BeansUsuario mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from usuarios where usu_cod=?");
            pst.setInt(1, mod.getUsuCod());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuario excluidos com sucesso!");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao excluir Usuario\n"+ex);
        }
        conex.desconecta();
    }
}
