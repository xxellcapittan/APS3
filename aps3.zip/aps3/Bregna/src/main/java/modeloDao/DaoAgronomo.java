/*
* Onde ficará os metodos de alteração/inserção dos dados
*/
package modeloDao;

import modeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.BeansAgronomo;


public class DaoAgronomo {
    ConexaoBD conex = new ConexaoBD();
    BeansAgronomo mod = new BeansAgronomo();
    
    public void Salvar(BeansAgronomo mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into agronomos(nome,especialidade,crea_agronomo) values(?,?,?) ");
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getEspecialidade());
            pst.setInt(3, mod.getCrea());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Os dados foram inseridos com sucesso!");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Os dados não foram: Falha!\n" + ex);
        }
        conex.desconecta();
    }
    
    public void Editar(BeansAgronomo mod){
            conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("update agronomos set nome=?,especialidade=?,crea_agronomo=? where cod_agronomo=?"); // set table medicos para edição/inserção de valores
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getEspecialidade());
            pst.setInt(3, mod.getCrea());
            pst.setInt(4, mod.getCodigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Exito ao alterar dados");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao alterar dados\n"+ex);
        }
            conex.desconecta();
            
    }
    
    public void Excluir(BeansAgronomo mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from agronomos where cod_agronomo=?");
            pst.setInt(1, mod.getCodigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados excluidos com sucesso!");
        } catch (SQLException ex) {
            //Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao excluir os dados\n"+ex);
        }
        conex.desconecta();
    }
    
    public BeansAgronomo buscaAgronomo(BeansAgronomo mod) {
        conex.conexao();
        conex.executaConsulta("select * from agronomos where nome like'%"+mod.getPesquisa()+"%'");
        try {
            conex.rs.first();
            mod.setCodigo(conex.rs.getInt("cod_agronomo"));
            mod.setNome(conex.rs.getString("nome"));
            mod.setCrea(conex.rs.getInt("crea_agronomo"));
            mod.setEspecialidade(conex.rs.getString("especialidade"));
        } catch (SQLException ex) {
          //  Logger.getLogger(DaoAgronomo.class.getName()).log(Level.SEVERE, null, ex);
          JOptionPane.showMessageDialog(null, "Agronomo não encontrado");
        }
        conex.desconecta();
        return mod;
        
    } 
        }
    

