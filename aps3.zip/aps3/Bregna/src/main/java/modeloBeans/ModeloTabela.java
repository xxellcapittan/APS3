
// 04/03/2020
package modeloBeans;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class ModeloTabela extends AbstractTableModel{
    private ArrayList linhas = null; // arraylist é uma coleção simples que pode armazenar qualquer tipo de objeto
    private String[] colunas = null;
    
    
public ModeloTabela(ArrayList lin, String[] col){
    setLinhas(lin);
    setColunas(col);
    
}

    /**
     * @return the linhas
     */
    public ArrayList getLinhas() {
        return linhas;
    }

    /**
     * @param linhas the linhas to set
     */
    public void setLinhas(ArrayList linhas) {
        this.linhas = linhas;
    }

    /**
     * @return the colunas
     */
    public String[] getColunas() {
        return colunas;
    }

    /**
     * @param colunas the colunas to set
     */
    public void setColunas(String[] colunas) {
        this.colunas = colunas;
    }
    
    // metodo para contar n de colunas 
    public int getColumnCount(){
        return colunas.length;
    }
    // contará quantas linhas tem no array
    public int getRowCount(){
        return linhas.size();
    }
    // pegar o valor do nome da coluna
    public String getColumnName(int numCol){
        return colunas[numCol];
    }
    // metodo que estará adicionando as linhas da table
    public Object getValueAt(int numLin, int numCol){
        Object[] linha = (Object[])getLinhas().get(numLin);
        return linha[numCol];
    }
}
