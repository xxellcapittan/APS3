/**
 * Responsavel pela declaracao dos atributos
 * encapsular os atributos e encapsular geters and setters
 */
package modeloBeans;


public class BeansAgronomo {

    /**
     * @return the pesquisa
     */
    public String getPesquisa() {
        return pesquisa;
    }

    /**
     * @param pesquisa the pesquisa to set
     */
    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    /**
     * @return the crea
     */
    public int getCrea() {
        return crea;
    }

    /**
     * @param crea the crea to set
     */
    public void setCrea(int crea) {
        this.crea = crea;
    }
    private int codigo;
    private String nome;
    private String especialidade;
    private int crea;
    private String pesquisa;
}
