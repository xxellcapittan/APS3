/*
 *Author: Maicon Aparecido
 * responsavel por realizar conexao com banco PostgreSQL
 */
package modeloConection;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;

public class ConexaoBD {
    public Statement stn;// pesquisa em DB
    public ResultSet rs; // armazenar resultado da pesquisa
   
    private String driver = "org.postgresql.Driver"; // identifica o servico
    private String caminho = "jdbc:postgresql://localhost/bregna"; // qual o caminho do DB
    private String usuario = "postgres"; // responsável por verificar usuário
    private String senha = "hx$$5661"; //idem anterior porém com a senha
    public Connection con; // responsavel por conectar com db 
    

    
    public void conexao(){
        
        try {
            System.setProperty("jdbc.Drivers", driver); // set propriedade driver de conexão
            con=DriverManager.getConnection(caminho, usuario, senha);
          //  JOptionPane.showMessageDialog(null, "conectado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: Por favor verifique!:\n"+ex.getMessage());
        }
    }
    
    public void executaConsulta (String sql){
        try {
            stn = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY); // vai diferir maiusculo de minusculos
            rs = stn.executeQuery(sql);
        } catch (SQLException ex) {
            //Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro de execução SQL!:\n"+ex.getMessage());
        }
    }
    
    public void desconecta(){
        try {
            con.close();
           // JOptionPane.showMessageDialog(null, "Desconectado com sucesso!");
        } catch (SQLException ex) {
            //Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null, "Falha ao desconectar!:\n" +ex.getMessage());
        }
    }
}
