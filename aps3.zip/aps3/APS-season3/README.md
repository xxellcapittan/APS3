# APS season3
 An system using design patterns, mvc, java and postgreSQL
